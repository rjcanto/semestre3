function [result]= correlador(Signal,FS,Modulation)
    [TB,Amp]=NRZValues();
    %constru��o do array de tempos
    bitsLen = length(0:1/(FS-1):TB);
    bitsnbr = length(Signal)/bitsLen;
    t = 0:(TB*bitsnbr)/(bitsLen*bitsnbr-1):TB*bitsnbr; 
    
    Signal=Signal.*cos(2*pi*10000*TB);
    tmpY=zeros(1,bitsLen);
    result=zeros(1,bitsnbr);
    
    for i=1:bitsnbr
        count=1;
        while (count <= bitsLen )
            idx=(i-1)*bitsLen+count;
            tmpY(count)=Signal(idx);
            count=count+1;
        end
        Y=sum(tmpY);
        result(i)=decisor(Y,Modulation);
    end
end