function [TB,Amp]=EmissorValues()
    %TB = Tempo de Bit
    %Amp= Amplitude Sinal
    %Fo = Frequ�ncia Portadora  
    %FS = Frequ�ncia de Amostragem, respeitando o ritmo de Nyquist
    TB=0.001;
    Amp=5;
    %FreqPort=10000;
    %FS=2.2*1/TB;
end