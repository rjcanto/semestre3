#ifndef MYLIB_H
#define MYLIB_H

#define SUCCESS 0;
#define UNSUCCESS 1;
enum boolean {false,true};
typedef unsigned char byte;

#endif
